## GC V1.0.15

**Updated to Minecraft 26.2**
- Datapack now works on the 26.2 version of Minecraft

