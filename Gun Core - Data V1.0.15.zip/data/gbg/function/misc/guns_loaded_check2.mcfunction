loot give @s loot gc:example_gun
return 1