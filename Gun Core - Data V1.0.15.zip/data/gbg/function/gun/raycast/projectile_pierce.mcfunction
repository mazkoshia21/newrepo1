scoreboard players add @p[tag=gbg.gun_shooter] gbg.raycast_distance 45
tag @s add gbg.gun_hit
