## Spawning the projectile with the new accuracy offset
#RAYCASTS/HITSCANS
execute store result score gbg.projectile_type gbg.temp run data get storage gbg:gun_data gbg.projectile_type
execute if score gbg.projectile_type gbg.temp matches 1 run function gbg:gun/raycast/projectile/bullet
execute if score gbg.projectile_type gbg.temp matches 2 run function gbg:gun/raycast/projectile/light_bullet
execute if score gbg.projectile_type gbg.temp matches 3 run function gbg:gun/raycast/projectile/pellets
execute if score gbg.projectile_type gbg.temp matches 4 run function gbg:gun/raycast/projectile/laser
execute if score gbg.projectile_type gbg.temp matches 5 run function gbg:gun/raycast/projectile/large_laser
execute if score gbg.projectile_type gbg.temp matches 6 run function gbg:gun/raycast/projectile/fire
execute if score gbg.projectile_type gbg.temp matches 7 run function gbg:gun/raycast/projectile/blaze_fire
execute if score gbg.projectile_type gbg.temp matches 10 run function gbg:gun/raycast/projectile/green_ray
execute if score gbg.projectile_type gbg.temp matches 11 run function gbg:gun/raycast/projectile/blue_ray
execute if score gbg.projectile_type gbg.temp matches 12 run function gbg:gun/raycast/projectile/pink_ray
execute if score gbg.projectile_type gbg.temp matches 13 run function gbg:gun/raycast/projectile/red_ray
execute if score gbg.projectile_type gbg.temp matches 14 run function gbg:gun/raycast/projectile/white_ray
execute if score gbg.projectile_type gbg.temp matches 15 run function gbg:gun/raycast/projectile/green_laser
execute if score gbg.projectile_type gbg.temp matches 16 run function gbg:gun/raycast/projectile/blue_laser
execute if score gbg.projectile_type gbg.temp matches 17 run function gbg:gun/raycast/projectile/yellow_laser
execute if score gbg.projectile_type gbg.temp matches 18 run function gbg:gun/raycast/projectile/orange_laser
execute if score gbg.projectile_type gbg.temp matches 19 run function gbg:gun/raycast/projectile/cyan_laser
execute if score gbg.projectile_type gbg.temp matches 20 run function gbg:gun/raycast/projectile/yellow_ray
#SLOWCASTS/PROJECTILES
execute store result score gbg.projectile_speed gbg.temp run data get storage gbg:gun_data gbg.projectile_speed
execute if score gbg.projectile_speed gbg.temp matches 2.. run function gbg:gun/slowcast/launch
#CUSTOM RAYCASTS
execute if score gbg.projectile_type gbg.temp matches 200.. unless score gbg.projectile_speed gbg.temp matches 2.. run function #gbg:custom_raycast
