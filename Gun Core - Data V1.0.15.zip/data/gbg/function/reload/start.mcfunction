# Stopping function if a gun is in both the mainhand and offhand
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{gbg_is_gun:1b}] if items entity @s weapon.offhand *[minecraft:custom_data~{gbg_is_gun:1b}] run return fail
# Cleaning Up Offhand & Mainhand
execute if items entity @s weapon.mainhand * run function gbg:reload/give
execute unless items entity @s weapon.mainhand * run function gbg:reload/replace
# Figuring Out the Gun and What Functions to Run
execute if entity @s[scores={gbg.cooldown=0}] run function gbg:reload/figure_out_gun
