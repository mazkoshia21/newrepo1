tellraw @a ["",{"text":"["},{"text":"Gun Core V1.0.15","color":"#5d96ff"},{"text":"] Datapack successfully loaded!"}]

## SCOREBOARDS
# General
scoreboard objectives add gbg.sneak minecraft.custom:minecraft.sneak_time
scoreboard objectives add gbg.cooldown dummy
scoreboard objectives add gbg.reloading_time dummy
scoreboard objectives add gbg.raycast_distance dummy
scoreboard objectives add gbg.recoil_type dummy
scoreboard objectives add gbg.burst_duration dummy
scoreboard objectives add gbg.id dummy
scoreboard players add total gbg.id 0
scoreboard objectives add gbg.temp dummy
scoreboard objectives add gbg.temp2 dummy
scoreboard objectives add gbg.is_zooming dummy
scoreboard objectives add gbg.is_using dummy
scoreboard objectives add gbg.using_time dummy
scoreboard objectives add gbg.has_respawned minecraft.custom:minecraft.time_since_death
scoreboard objectives add gbg.shot_cycle dummy
scoreboard objectives add gbg.projectile_swap_detection dummy

# Throwable
scoreboard objectives add gbg.throwable.click dummy
scoreboard objectives add gbg.throwable.life dummy
scoreboard objectives add gbg.throwable.impact_type dummy
scoreboard objectives add gbg.throwable.explode_on_impact dummy

# Medical Item
scoreboard objectives add gbg.medical.effect_type dummy
scoreboard objectives add gbg.medical.use_time dummy
scoreboard objectives add gbg.medical.sound_time dummy

# Slowcast
scoreboard objectives add gbg.slowcast.damage dummy
scoreboard objectives add gbg.slowcast.headshot_damage dummy
scoreboard objectives add gbg.slowcast.max_range dummy
scoreboard objectives add gbg.slowcast.range dummy
scoreboard objectives add gbg.slowcast.projectile_type dummy
scoreboard objectives add gbg.slowcast.damage_type dummy
scoreboard objectives add gbg.slowcast.projectile_speed dummy

# Config
scoreboard objectives add config.gbg dummy
scoreboard players add are_guns_loaded config.gbg 0
scoreboard players add actionbar_reloading_appears config.gbg 0
scoreboard players add actionbar_item_use_appears config.gbg 0
scoreboard players add default_turret_target_type config.gbg 0
scoreboard players add turret_despawn_time config.gbg 0
scoreboard players add c4_detonate_limit config.gbg 0

# Misc
scoreboard objectives add gb.datapack_detect dummy
scoreboard players add gbz gb.datapack_detect 0
scoreboard players set gbg gb.datapack_detect 0
scoreboard players set modern_guns gb.datapack_detect 0
scoreboard players set pipe_guns gb.datapack_detect 0
scoreboard players set power_armor gb.datapack_detect 0
scoreboard players set gc gb.datapack_detect 0
schedule function gc:scoreboard_add 30t replace
schedule function gbg:misc/fix_jammed_guns 20t replace
function gbg:misc/import_numbers

