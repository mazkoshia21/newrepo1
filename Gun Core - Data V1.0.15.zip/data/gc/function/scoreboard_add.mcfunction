#scheduling itself
schedule function gc:scoreboard_add 4s replace
scoreboard players set gc gb.datapack_detect 1

#scoreboards
execute as @a unless score @s gbg.id matches 1.. run function gbg:misc/id_add
scoreboard players add @a gbg.cooldown 0

#checking if pack loaded properly
execute unless score are_guns_loaded config.gbg matches 1 unless function gbg:misc/guns_loaded_check run tellraw @a [{color:"red",text:"⚠",extra:[{bold:true,text:" WARNING "},"⚠"]},"\n",{color:"yellow",text:"You have added Gun Core to your world without fully restarting!"},"\n",{color:"yellow",text:"This means some guns will not load properly!"},"\n",{color:"gold",bold:true,text:"To fix this:"},"\n",{color:"yellow",text:"Singleplayer "},{color:"gray",text:"->"},{color:"red",text:" "},{color:"white",text:"Leave the world and rejoin"},"\n",{color:"yellow",text:"Multiplayer "},{color:"gray",text:"->"},{color:"red",text:" "},{color:"white",text:"Restart the server"},"\n",{color:"gray",italic:true,text:"If done successfully, this message will not appear upon rejoining."}]
