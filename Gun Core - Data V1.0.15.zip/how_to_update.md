## Take the most recent version of GBG datapack:
Add the following files from the previous verison of Gun Core
- data/gc/ *(The entire directory.)*
- data/minecraft/tags/function/load.json
- /how_to_update.txt
- /pack.mcmeta
- /pack.png
- /LICENSE.md *(Also, delete the old `LICENSE.txt` file.)*

Delete the following folders:
- /data/config/
- /data/give/
- /data/gbg/recipe/
- /data/gbg/loot_table/items/
- /data/gbg/loot_table/turret_salvage/
- /data/gbg/function/equipment/
- /data/gbg/function/turret/
- /data/gbg/function/config/
- /data/gbg/function/ui/
- /data/gbg/function/medical/use

Delete the following files:
- /data/gbg/advancement/first_player_dialog.json

Move the following files:
- Move the load.mcfunction file from the gbg namespace to the gc namespace

Inside /data/gbg/function/tick.mcfunction:
- Remove all lines except for the player looping function

Inside /data/gbg/function/player_loop.mcfunction:
- Remove the lines pertaining to the trigger commands
- Remove the lines for land mine exploding

Inside /data/gbg/function/load.mcfunction:
- Change the load message to say "Gun Core"
- Remove the lines for the turret and trigger scoreboards
- Change `scoreboard players set gbg gb.datapack_detect 1` to `scoreboard players add gbg gb.datapack_detect 0`
- Copy to the `gc` namespace if there exist significant differences

Inside /data/gbg/function/misc/scoreboard_add.mcfunction:
- Remove the lines giving the recipes for the GBG items
- Change the non loaded properly line to say "Gun Core" instead of "Gamingbarn's Guns"
- Remove the scoreboard assignment for `gbg.behind_cover`
- Remove the scoreboard assignment for `gbg gb.datapack_detect`
- Copy to the `gc` namespace if there exist significant differences

Inside /data/gbg/function/misc/guns_loaded_check2.mcfunction:
- Change the loot table file to reference `gc:example_gun`

## Take the most recent version of GBG resource pack:
Delete the following folders:
- assets/gbg/font/
- assets/gbg/items/
- assets/gbg/models/
- assets/gbg/textures/
- assets/gbg/sounds/gun/distant_shoot/
- assets/gbg/sounds/gun/shoot/
- assets/gbg/sounds/gun/reload/
- assets/gbg/sounds/medical/
- assets/gbg/sounds/turret/
- assets/gbg/sounds/equipment/

Add the following files from the previous verison of Gun Core
- /pack.png

Inside /pack.mcmeta
- Change the description to "The essential resource pack for §aGun Core"

Inside /version.txt
- Change the text to say what version of Gun Core it's for

