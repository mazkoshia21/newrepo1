## Gamingbarn Gun Core License (GGCL) v1.1

### 1. Grant of License
The licensor (Gamingbarn) grants any individual or entity (the Licensee) permission to use, modify, and distribute the Gun Core datapack/mod (the Software) under the terms specified in this agreement.

### 2. Permitted Uses
- The Licensee may download, modify, and bundle the Software within their own Minecraft datapack/mod.
- The Licensee may distribute the Software, including modified versions, as part of their own datapack/mod.
- The Licensee may publicly showcase and use the Software in videos, streams, or other media.
- The Licensee may distribute a modified version of Gun Core as a standalone project/library, provided:
**A)** It does not claim to be the official version, and
**B)** It clearly states that it is a fork or modified version.

### 3. Attribution Requirement
If the Licensee distributes a datapack/mod that includes Gun Core (modified or unmodified), they must provide clear attribution by including a link to either:
- The official Gun Core project page, OR
- Gamingbarn's profile page (if a project page is unavailable).

This attribution must be visible in any description, credits, or documentation provided with the datapack/mod.

### 4. Recommendation for Linking Instead of Bundling
The Licensor strongly recommends that the Licensee does not bundle Gun Core and instead provides a link for players to download it separately. This recommendation is made for the following reasons:
- Future bug fixes will apply automatically without requiring the Licensee to update their own datapack/mod.
- Gun Core may receive updates for multiple Minecraft versions, reducing compatibility issues.
- Downloading from the project page supports Gamingbarn, helping sustain further development.

### 5. Prohibited Actions
The Licensee may not:
- Claim credit for the original Gun Core software.
- Sell Gun Core, or a modified version, as a standalone product.
- Remove or modify required attribution when bundling Gun Core in a datapack/mod, or when distributing a modified standalone version.

### 6. Disclaimer of Warranty
The Software is provided "as is" without warranty of any kind. The Licensor is not responsible for any damages, loss of data, or issues arising from the use of the Software.

### 7. Termination of License
Failure to comply with this license may result in the termination of the Licensee's right to use and distribute Gun Core. The Licensor reserves the right to take action against any violations.